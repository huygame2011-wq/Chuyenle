package com.spicy.client.module.movement;

import com.spicy.client.module.Category;
import com.spicy.client.module.Module;
import net.minecraft.client.MinecraftClient;

public final class MovementModules {
    private MovementModules() {}

    /** Tu dong chay nhanh khi giu phim tien. */
    public static final class Sprint extends Module {
        public Sprint() { super("Sprint", "Tự động chạy nhanh khi bạn giữ phím đi tiến.", Category.MOVEMENT); }
        @Override public void onTick(MinecraftClient mc) {
            if (mc.player == null || mc.currentScreen != null) return;
            mc.options.sprintKey.setPressed(mc.options.forwardKey.isPressed());
        }
        @Override protected void onDisable() {
            MinecraftClient mc = MinecraftClient.getInstance();
            if (mc.options != null) mc.options.sprintKey.setPressed(false);
        }
    }

    /** Dung cai dat "Toggle Sneak" cua game: bam 1 lan de cui, bam lai de dung. */
    public static final class ToggleSneak extends Module {
        private boolean previous;
        public ToggleSneak() { super("Toggle Sneak", "Bấm một lần để cúi, bấm lại để thôi cúi (không cần giữ phím).", Category.MOVEMENT); }
        @Override protected void onEnable() {
            var o = MinecraftClient.getInstance().options;
            previous = o.getSneakToggled().getValue();
            o.getSneakToggled().setValue(true);
        }
        @Override protected void onDisable() {
            var o = MinecraftClient.getInstance().options;
            if (o != null) o.getSneakToggled().setValue(previous);
        }
        @Override public void onShutdown() { onDisable(); }
    }

    /** Dung cai dat "Auto-Jump" cua game: tu nhay len khoi vuong khi di tien. */
    public static final class AutoJump extends Module {
        private boolean previous;
        public AutoJump() { super("Auto Jump", "Tự động nhảy lên bậc/khối khi bạn đi tiến.", Category.MOVEMENT); }
        @Override protected void onEnable() {
            var o = MinecraftClient.getInstance().options;
            previous = o.getAutoJump().getValue();
            o.getAutoJump().setValue(true);
        }
        @Override protected void onDisable() {
            var o = MinecraftClient.getInstance().options;
            if (o != null) o.getAutoJump().setValue(previous);
        }
        @Override public void onShutdown() { onDisable(); }
    }
}
