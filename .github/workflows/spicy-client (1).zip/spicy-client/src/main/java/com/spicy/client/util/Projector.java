package com.spicy.client.util;

import net.minecraft.client.MinecraftClient;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

/**
 * Chieu toa do the gioi sang toa do man hinh GUI (ve overlay 2D len HUD).
 * Phan toan hoc khong phu thuoc Minecraft. Chi dung dung o goc nhin thu nhat.
 * FOV doc tu cai dat game nen se lech nhe khi hieu ung FOV (chay nhanh) dang bat.
 */
public final class Projector {
    private static final double NEAR = 0.05;

    public final int sw, sh;
    private final double px, py, pz;
    private final double fx, fy, fz, rx, rz, ux, uy, uz;
    private final double tan, aspect;

    private Projector(double px, double py, double pz, double yawDeg, double pitchDeg, double fovDeg, int sw, int sh) {
        this.px = px; this.py = py; this.pz = pz;
        double yaw = Math.toRadians(yawDeg), pitch = Math.toRadians(pitchDeg);
        fx = -Math.sin(yaw) * Math.cos(pitch);
        fy = -Math.sin(pitch);
        fz = Math.cos(yaw) * Math.cos(pitch);
        rx = -Math.cos(yaw);
        rz = -Math.sin(yaw);
        // up = right x forward (ry = 0)
        ux = -rz * fy;
        uy = rz * fx - rx * fz;
        uz = rx * fy;
        this.tan = Math.tan(Math.toRadians(fovDeg) / 2.0);
        this.sw = sw; this.sh = sh;
        this.aspect = (double) sw / sh;
    }

    /** Dung thu cong (dung cho kiem thu). */
    public static Projector of(double x, double y, double z, double yaw, double pitch, double fov, int sw, int sh) {
        return new Projector(x, y, z, yaw, pitch, fov, sw, sh);
    }

    /** Tao tu trang thai nguoi choi; tra ve null neu khong ve duoc (chua vao the gioi, goc nhin thu ba). */
    public static Projector create(MinecraftClient mc, float partialTick) {
        var p = mc.player;
        if (p == null || mc.world == null) return null;
        if (!mc.options.getPerspective().isFirstPerson()) return null;
        Vec3d lp = p.getLerpedPos(partialTick);
        double eye = lp.y + (p.getEyeY() - p.getY());
        int sw = mc.getWindow().getScaledWidth(), sh = mc.getWindow().getScaledHeight();
        if (sw <= 0 || sh <= 0) return null;
        return new Projector(lp.x, eye, lp.z, p.getYaw(partialTick), p.getPitch(partialTick),
                mc.options.getFov().getValue(), sw, sh);
    }

    /** Chieu 1 diem. out = {x, y} theo toa do GUI. False neu diem nam sau camera. */
    public boolean project(double x, double y, double z, double[] out) {
        double dx = x - px, dy = y - py, dz = z - pz;
        double cz = dx * fx + dy * fy + dz * fz;
        if (cz <= NEAR) return false;
        double cx = dx * rx + dz * rz;                 // ry = 0
        double cy = dx * ux + dy * uy + dz * uz;
        double ndcX = cx / (cz * tan * aspect);
        double ndcY = cy / (cz * tan);
        out[0] = (ndcX * 0.5 + 0.5) * sw;
        out[1] = (0.5 - ndcY * 0.5) * sh;
        return true;
    }

    /** Chieu hop 3D thanh hinh chu nhat 2D bao quanh {x1,y1,x2,y2}. False neu bat ky goc nao sau camera. */
    public boolean projectBox(Box b, int[] rect) {
        double[] o = new double[2];
        double minX = Double.MAX_VALUE, minY = Double.MAX_VALUE, maxX = -Double.MAX_VALUE, maxY = -Double.MAX_VALUE;
        for (int i = 0; i < 8; i++) {
            double x = (i & 1) == 0 ? b.minX : b.maxX;
            double y = (i & 2) == 0 ? b.minY : b.maxY;
            double z = (i & 4) == 0 ? b.minZ : b.maxZ;
            if (!project(x, y, z, o)) return false;
            minX = Math.min(minX, o[0]); maxX = Math.max(maxX, o[0]);
            minY = Math.min(minY, o[1]); maxY = Math.max(maxY, o[1]);
        }
        if (maxX < 0 || minX > sw || maxY < 0 || minY > sh) return false; // ngoai man hinh
        if (maxX - minX > sw * 3 || maxY - minY > sh * 3) return false;   // qua lon (dang o sat)
        rect[0] = (int) minX; rect[1] = (int) minY; rect[2] = (int) maxX; rect[3] = (int) maxY;
        return true;
    }
}
