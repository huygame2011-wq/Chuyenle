package com.spicy.client.module;

public enum Category {
    COMBAT("Chiến đấu"),
    MOVEMENT("Di chuyển"),
    RENDER("Hiển thị"),
    RAID_ANALYSIS("Phân tích căn cứ"),
    UTILITY("Tiện ích");

    public final String label;
    Category(String label) { this.label = label; }
}
