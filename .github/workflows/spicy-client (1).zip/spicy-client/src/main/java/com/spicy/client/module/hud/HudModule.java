package com.spicy.client.module.hud;

import com.spicy.client.module.Category;
import com.spicy.client.module.Module;
import com.spicy.client.setting.Setting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

/** Module HUD co vi tri, kich thuoc, mau, nen mo chinh duoc. Lop con chi can ve noi dung. */
public abstract class HudModule extends Module {
    protected final Setting.Num x;
    protected final Setting.Num y;
    protected final Setting.Num scale = add(new Setting.Num("Scale", "Kích thước", 1.0, 0.5, 3.0));
    protected final Setting.Color color = add(new Setting.Color("Color", "Màu sắc", 0xFFC77DFF));
    protected final Setting.Bool background = add(new Setting.Bool("Background", "Nền mờ", true));

    protected HudModule(String name, String description, Category cat, int defX, int defY) {
        super(name, description, cat);
        this.x = add(new Setting.Num("X", "Vị trí ngang (X)", defX, 0, 1000));
        this.y = add(new Setting.Num("Y", "Vị trí dọc (Y)", defY, 0, 1000));
    }

    /** Ve noi dung tai goc (0,0); he thong tu dich chuyen + scale. */
    protected abstract void renderContent(DrawContext ctx, MinecraftClient mc);

    /** Ve nhieu dong chu (kem nen mo neu bat). */
    protected void lines(DrawContext ctx, MinecraftClient mc, String... ls) {
        int w = 0;
        for (String l : ls) w = Math.max(w, mc.textRenderer.getWidth(l));
        if (background.get()) ctx.fill(-2, -2, w + 2, ls.length * 10, 0x90000000);
        for (int i = 0; i < ls.length; i++)
            ctx.drawTextWithShadow(mc.textRenderer, ls[i], 0, i * 10, color.get());
    }

    @Override
    public final void onHudRender(DrawContext ctx, MinecraftClient mc) {
        var m = ctx.getMatrices();
        m.pushMatrix();
        m.translate(x.f(), y.f());
        m.scale(scale.f(), scale.f());
        try {
            renderContent(ctx, mc);
        } finally {
            m.popMatrix();
        }
    }
}
