package com.spicy.client.module.hud;

import com.spicy.client.SpicyClient;
import com.spicy.client.module.Category;
import com.spicy.client.setting.Setting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.math.MathHelper;

import java.util.ArrayDeque;
import java.util.Locale;

/** Tat ca module HUD. Vi tri mac dinh xep thanh 2 cot de khong de len nhau. */
public final class HudModules {
    private HudModules() {}

    private static String f1(double v) { return String.format(Locale.ROOT, "%.1f", v); }

    // ---------------------------------------------------------------- Utility
    public static final class Ping extends HudModule {
        public Ping() { super("Ping", "Hiển thị độ trễ mạng (ms).", Category.UTILITY, 4, 16); }
        @Override protected void renderContent(DrawContext ctx, MinecraftClient mc) {
            String s = "N/A";
            if (mc.player != null && mc.getNetworkHandler() != null) {
                PlayerListEntry e = mc.getNetworkHandler().getPlayerListEntry(mc.player.getUuid());
                if (e != null) s = e.getLatency() + " ms";
            }
            lines(ctx, mc, "Ping: " + s);
        }
    }

    public static final class Timer extends HudModule {
        private long start;
        public Timer() { super("Timer", "Đồng hồ bấm giờ: đếm từ lúc bật module (tắt rồi bật lại để đặt về 0).", Category.UTILITY, 4, 76); }
        @Override protected void onEnable() { start = System.currentTimeMillis(); }
        @Override protected void renderContent(DrawContext ctx, MinecraftClient mc) {
            long ms = System.currentTimeMillis() - start;
            long min = ms / 60000, sec = (ms / 1000) % 60, tenth = (ms / 100) % 10;
            lines(ctx, mc, String.format(Locale.ROOT, "Timer: %02d:%02d.%d", min, sec, tenth));
        }
    }

    public static final class ArmorDurability extends HudModule {
        private static final String[] NAMES = {"Mũ", "Áo", "Quần", "Giày"};
        private static final EquipmentSlot[] SLOTS = {
                EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};
        public ArmorDurability() { super("Armor Durability", "Hiển thị độ bền từng món giáp đang mặc.", Category.UTILITY, 4, 100); }
        @Override protected void renderContent(DrawContext ctx, MinecraftClient mc) {
            if (mc.player == null) return;
            java.util.List<String> out = new java.util.ArrayList<>();
            for (int i = 0; i < 4; i++) {
                ItemStack s = mc.player.getEquippedStack(SLOTS[i]);
                if (s.isEmpty()) continue;
                if (s.isDamageable()) {
                    int left = s.getMaxDamage() - s.getDamage();
                    out.add(NAMES[i] + ": " + left + "/" + s.getMaxDamage() + " (" + (left * 100 / s.getMaxDamage()) + "%)");
                } else {
                    out.add(NAMES[i] + ": không có độ bền");
                }
            }
            if (out.isEmpty()) out.add("Không mặc giáp");
            lines(ctx, mc, out.toArray(new String[0]));
        }
    }

    public static final class PotionHud extends HudModule {
        public PotionHud() { super("Potion HUD", "Danh sách hiệu ứng thuốc và thời gian còn lại.", Category.UTILITY, 120, 4); }
        @Override protected void renderContent(DrawContext ctx, MinecraftClient mc) {
            if (mc.player == null) return;
            java.util.List<String> out = new java.util.ArrayList<>();
            for (StatusEffectInstance e : mc.player.getStatusEffects()) {
                String name = e.getEffectType().value().getName().getString();
                String time;
                if (e.getDuration() < 0) time = "∞";
                else {
                    int sec = e.getDuration() / 20;
                    time = String.format(Locale.ROOT, "%d:%02d", sec / 60, sec % 60);
                }
                out.add(name + " " + (e.getAmplifier() + 1) + "  " + time);
            }
            if (out.isEmpty()) out.add("Không có hiệu ứng");
            lines(ctx, mc, out.toArray(new String[0]));
        }
    }

    public static final class Keystrokes extends HudModule {
        public Keystrokes() { super("Keystrokes", "Hiển thị phím W A S D, chuột trái/phải và phím cách khi bấm.", Category.UTILITY, 4, 162); }
        private void key(DrawContext ctx, MinecraftClient mc, int x, int y, int w, int h, String label, boolean down) {
            int accent = (color.get() & 0x00FFFFFF) | 0xB0000000;
            ctx.fill(x, y, x + w, y + h, down ? accent : 0x80000000);
            ctx.drawTextWithShadow(mc.textRenderer, label,
                    x + (w - mc.textRenderer.getWidth(label)) / 2, y + (h - 8) / 2, 0xFFFFFFFF);
        }
        @Override protected void renderContent(DrawContext ctx, MinecraftClient mc) {
            var o = mc.options;
            key(ctx, mc, 18, 0, 16, 16, "W", o.forwardKey.isPressed());
            key(ctx, mc, 0, 18, 16, 16, "A", o.leftKey.isPressed());
            key(ctx, mc, 18, 18, 16, 16, "S", o.backKey.isPressed());
            key(ctx, mc, 36, 18, 16, 16, "D", o.rightKey.isPressed());
            key(ctx, mc, 0, 36, 25, 16, "LMB", o.attackKey.isPressed());
            key(ctx, mc, 27, 36, 25, 16, "RMB", o.useKey.isPressed());
            key(ctx, mc, 0, 54, 52, 12, "SPACE", o.jumpKey.isPressed());
        }
    }

    public static final class InventoryHud extends HudModule {
        public InventoryHud() { super("Inventory HUD", "Hiển thị 27 ô túi đồ (không gồm thanh nhanh) trên màn hình.", Category.UTILITY, 120, 80); }
        @Override protected void renderContent(DrawContext ctx, MinecraftClient mc) {
            if (mc.player == null) return;
            if (background.get()) ctx.fill(-2, -2, 9 * 18 + 2, 3 * 18 + 2, 0x90000000);
            var inv = mc.player.getInventory();
            for (int i = 0; i < 27; i++) {
                ItemStack s = inv.getStack(9 + i);
                if (s.isEmpty()) continue;
                int sx = (i % 9) * 18, sy = (i / 9) * 18;
                ctx.drawItem(s, sx, sy);
                ctx.drawStackOverlay(mc.textRenderer, s, sx, sy);
            }
        }
    }

    // ---------------------------------------------------------------- Movement
    public static final class Speed extends HudModule {
        private double lx, lz, speed;
        private boolean have;
        public Speed() { super("Speed Display", "Hiển thị tốc độ di chuyển ngang (block/giây).", Category.MOVEMENT, 4, 40); }
        @Override protected void onEnable() { have = false; speed = 0; }
        @Override public void onTick(MinecraftClient mc) {
            if (mc.player == null) { have = false; return; }
            double px = mc.player.getX(), pz = mc.player.getZ();
            if (have) {
                double d = Math.sqrt((px - lx) * (px - lx) + (pz - lz) * (pz - lz)) * 20.0;
                speed = speed * 0.6 + d * 0.4; // lam muot
            }
            lx = px; lz = pz; have = true;
        }
        @Override protected void renderContent(DrawContext ctx, MinecraftClient mc) {
            lines(ctx, mc, "Tốc độ: " + String.format(Locale.ROOT, "%.2f", speed) + " block/s");
        }
    }

    public static final class Direction extends HudModule {
        public Direction() { super("Direction HUD", "Hiển thị hướng nhìn (Bắc/Nam/Đông/Tây) và góc quay.", Category.MOVEMENT, 4, 52); }
        @Override protected void renderContent(DrawContext ctx, MinecraftClient mc) {
            if (mc.player == null) return;
            String d = switch (mc.player.getHorizontalFacing()) {
                case NORTH -> "Bắc";
                case SOUTH -> "Nam";
                case EAST -> "Đông";
                case WEST -> "Tây";
                default -> "?";
            };
            float yaw = MathHelper.wrapDegrees(mc.player.getYaw());
            lines(ctx, mc, "Hướng: " + d + " (" + Math.round(yaw) + "°)");
        }
    }

    // ---------------------------------------------------------------- Render
    public static final class Coordinates extends HudModule {
        public Coordinates() { super("Coordinates", "Hiển thị tọa độ X / Y / Z của bạn.", Category.RENDER, 4, 28); }
        @Override protected void renderContent(DrawContext ctx, MinecraftClient mc) {
            if (mc.player == null) return;
            lines(ctx, mc, "XYZ: " + f1(mc.player.getX()) + " / " + f1(mc.player.getY()) + " / " + f1(mc.player.getZ()));
        }
    }

    // ---------------------------------------------------------------- Combat
    /** CPS dem theo tung tick (20 lan/giay) nen la so uoc luong, co the thap hon thuc te khi click rat nhanh. */
    public static final class Cps extends HudModule {
        private final ArrayDeque<Long> left = new ArrayDeque<>(), right = new ArrayDeque<>();
        private boolean lastL, lastR;
        public Cps() { super("CPS", "Đếm số lần click chuột trái | phải mỗi giây (ước lượng theo tick).", Category.COMBAT, 4, 64); }
        @Override public void onTick(MinecraftClient mc) {
            boolean in = mc.player != null && mc.currentScreen == null;
            boolean l = in && mc.options.attackKey.isPressed();
            boolean r = in && mc.options.useKey.isPressed();
            long now = System.currentTimeMillis();
            if (l && !lastL) left.add(now);
            if (r && !lastR) right.add(now);
            lastL = l; lastR = r;
        }
        private static int count(ArrayDeque<Long> q) {
            long limit = System.currentTimeMillis() - 1000;
            while (!q.isEmpty() && q.peekFirst() < limit) q.pollFirst();
            return q.size();
        }
        @Override protected void renderContent(DrawContext ctx, MinecraftClient mc) {
            lines(ctx, mc, "CPS: " + count(left) + " | " + count(right));
        }
    }

    public static final class ArmorHud extends HudModule {
        private static final EquipmentSlot[] SLOTS = {
                EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};
        public ArmorHud() { super("Armor HUD", "Hiển thị biểu tượng giáp đang mặc kèm thanh độ bền.", Category.COMBAT, 120, 138); }
        @Override protected void renderContent(DrawContext ctx, MinecraftClient mc) {
            if (mc.player == null) return;
            for (int i = 0; i < 4; i++) {
                ItemStack s = mc.player.getEquippedStack(SLOTS[i]);
                if (s.isEmpty()) continue;
                ctx.drawItem(s, 0, i * 18);
                ctx.drawStackOverlay(mc.textRenderer, s, 0, i * 18);
            }
        }
    }

    public static final class TotemCounter extends HudModule {
        public TotemCounter() { super("Totem Counter", "Đếm số Totem bất tử trong túi đồ (kể cả tay phụ).", Category.COMBAT, 4, 142); }
        @Override protected void renderContent(DrawContext ctx, MinecraftClient mc) {
            if (mc.player == null) return;
            int n = 0;
            var inv = mc.player.getInventory();
            for (int i = 0; i < inv.size(); i++) {
                ItemStack s = inv.getStack(i);
                if (s.isOf(Items.TOTEM_OF_UNDYING)) n += s.getCount();
            }
            ctx.drawItem(new ItemStack(Items.TOTEM_OF_UNDYING), 0, 0);
            ctx.drawTextWithShadow(mc.textRenderer, "x " + n, 20, 4, n == 0 ? 0xFFF87171 : color.get());
        }
    }

    public static final class TargetHud extends HudModule {
        private LivingEntity last;
        private long lastMs;
        public TargetHud() { super("Target HUD", "Hiển thị tên và máu của sinh vật bạn đang nhìn vào.", Category.COMBAT, 120, 50); }
        @Override public void onTick(MinecraftClient mc) {
            if (mc.crosshairTarget instanceof EntityHitResult r && r.getEntity() instanceof LivingEntity le) {
                last = le;
                lastMs = System.currentTimeMillis();
            }
        }
        @Override protected void renderContent(DrawContext ctx, MinecraftClient mc) {
            if (last == null || !last.isAlive() || System.currentTimeMillis() - lastMs > 3000) return;
            String name = last.getName().getString();
            float hp = last.getHealth(), max = Math.max(1f, last.getMaxHealth());
            float r = MathHelper.clamp(hp / max, 0f, 1f);
            int w = Math.max(90, mc.textRenderer.getWidth(name));
            if (background.get()) ctx.fill(-2, -2, w + 2, 30, 0x90000000);
            ctx.drawTextWithShadow(mc.textRenderer, name, 0, 0, color.get());
            ctx.drawTextWithShadow(mc.textRenderer, "HP: " + f1(hp) + " / " + f1(max), 0, 10, 0xFFFFFFFF);
            ctx.fill(0, 21, w, 25, 0xFF3B2F55);
            ctx.fill(0, 21, (int) (w * r), 25, r > 0.5f ? 0xFF4ADE80 : r > 0.25f ? 0xFFFACC15 : 0xFFF87171);
        }
    }

    /** Chi DOC va hien thi khoang cach toi muc tieu, KHONG thay doi tam danh. */
    public static final class ReachDisplay extends HudModule {
        private double reach;
        private long lastMs;
        public ReachDisplay() { super("Reach Display", "Hiển thị khoảng cách tới sinh vật bạn đang nhìn (chỉ hiển thị, không thay đổi gì).", Category.COMBAT, 4, 88); }
        @Override public void onTick(MinecraftClient mc) {
            if (mc.player != null && mc.crosshairTarget instanceof EntityHitResult r) {
                reach = mc.player.getEyePos().distanceTo(r.getPos());
                lastMs = System.currentTimeMillis();
            }
        }
        @Override protected void renderContent(DrawContext ctx, MinecraftClient mc) {
            boolean fresh = System.currentTimeMillis() - lastMs < 2000;
            lines(ctx, mc, "Reach: " + (fresh ? String.format(Locale.ROOT, "%.2f", reach) : "--"));
        }
    }

    // ---------------------------------------------------------------- Danh sach module + dong ho
    public static final class ModuleList extends HudModule {
        private final Setting.Mode sort = add(new Setting.Mode("Sort", "Sắp xếp", new String[]{"Theo độ dài", "Theo tên"}, 0));
        public ModuleList() { super("Module List", "Danh sách các module đang bật.", Category.UTILITY, 300, 4); }
        @Override protected void renderContent(DrawContext ctx, MinecraftClient mc) {
            java.util.List<String> names = new java.util.ArrayList<>();
            for (var m : SpicyClient.modules.all()) if (m.isEnabled() && m != this) names.add(m.getName());
            if (names.isEmpty()) { lines(ctx, mc, "Không có module nào bật"); return; }
            if (sort.index() == 0) names.sort((a, b) -> mc.textRenderer.getWidth(b) - mc.textRenderer.getWidth(a));
            else names.sort(String::compareToIgnoreCase);
            lines(ctx, mc, names.toArray(new String[0]));
        }
    }

    public static final class Clock extends HudModule {
        private static final java.time.format.DateTimeFormatter F24 = java.time.format.DateTimeFormatter.ofPattern("HH:mm:ss", Locale.ROOT);
        private static final java.time.format.DateTimeFormatter F12 = java.time.format.DateTimeFormatter.ofPattern("hh:mm:ss a", Locale.ROOT);
        private final Setting.Mode format = add(new Setting.Mode("Format", "Định dạng giờ", new String[]{"24 giờ", "12 giờ"}, 0));
        public Clock() { super("Clock", "Hiển thị giờ hiện tại của máy.", Category.UTILITY, 4, 114); }
        @Override protected void renderContent(DrawContext ctx, MinecraftClient mc) {
            var f = format.index() == 0 ? F24 : F12;
            lines(ctx, mc, "Giờ: " + java.time.LocalTime.now().format(f));
        }
    }
}
