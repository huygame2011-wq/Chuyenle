package com.spicy.client.module.utility;

import com.spicy.client.SpicyClient;
import com.spicy.client.module.Category;
import com.spicy.client.module.Module;
import com.spicy.client.setting.Setting;
import net.minecraft.client.MinecraftClient;

public final class UtilityModules {
    private UtilityModules() {}

    /** Tu dong hoi sinh sau khi chet (dung chuc nang hoi sinh cua game, co the cho vai tick). */
    public static final class AutoRespawn extends Module {
        private final Setting.Num delay = add(new Setting.Num("Delay", "Chờ trước khi hồi sinh (tick)", 10, 0, 100));
        private int wait;
        public AutoRespawn() { super("Auto Respawn", "Tự động bấm hồi sinh khi bạn chết.", Category.UTILITY); }
        @Override protected void onEnable() { wait = 0; }
        @Override public void onTick(MinecraftClient mc) {
            var p = mc.player;
            if (p == null) return;
            if (p.isDead()) {
                if (++wait >= delay.i()) {
                    p.requestRespawn();
                    wait = 0;
                    SpicyClient.notifications.push("Đã tự hồi sinh", 0xFFC77DFF);
                }
            } else {
                wait = 0;
            }
        }
    }
}
