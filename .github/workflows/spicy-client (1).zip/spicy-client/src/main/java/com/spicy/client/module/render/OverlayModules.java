package com.spicy.client.module.render;

import com.spicy.client.SpicyClient;
import com.spicy.client.module.Category;
import com.spicy.client.module.Module;
import com.spicy.client.module.raid.RaidModules;
import com.spicy.client.setting.Setting;
import com.spicy.client.util.Projector;
import com.spicy.client.util.Waypoints;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.util.ScreenshotRecorder;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

import java.util.Locale;

/**
 * Cac module ve len man hinh bang cach chieu toa do the gioi sang toa do GUI (overlay 2D, khong phai khung 3D that).
 * Chi hoat dong o goc nhin thu nhat. Cac module ESP / Hitbox / Chest Display chi dung trong the gioi 1 nguoi choi.
 */
public final class OverlayModules {
    private OverlayModules() {}

    private static int noteSlot;
    /** Goi dau moi frame de xep cac dong thong bao khong de len nhau. */
    public static void resetNotes() { noteSlot = 0; }

    // ------------------------------------------------------------ co so
    private abstract static class Overlay extends Module {
        protected final Setting.Color color;

        protected Overlay(String name, String desc, Category cat, int argb) {
            super(name, desc, cat);
            color = add(new Setting.Color("Color", "Màu sắc", argb));
        }

        protected boolean singleplayerOnly() { return false; }
        protected abstract void draw(DrawContext ctx, MinecraftClient mc, Projector pj);

        @Override
        public final void onHudRender(DrawContext ctx, MinecraftClient mc) {
            if (mc.player == null || mc.world == null || mc.currentScreen != null) return;
            if (singleplayerOnly() && !mc.isInSingleplayer()) {
                ctx.drawTextWithShadow(mc.textRenderer, getName() + ": chỉ dùng trong thế giới 1 người chơi",
                        4, 4 + 10 * noteSlot++, 0xFFF87171);
                return;
            }
            Projector pj = Projector.create(mc, SpicyClient.partialTick);
            if (pj == null) return; // goc nhin thu ba / chua vao the gioi
            draw(ctx, mc, pj);
        }

        protected static void outline(DrawContext c, int x1, int y1, int x2, int y2, int col) {
            c.fill(x1, y1, x2, y1 + 1, col);
            c.fill(x1, y2 - 1, x2, y2, col);
            c.fill(x1, y1, x1 + 1, y2, col);
            c.fill(x2 - 1, y1, x2, y2, col);
        }

        protected static void label(DrawContext c, MinecraftClient mc, String t, int cx, int y, int col) {
            c.drawTextWithShadow(mc.textRenderer, t, cx - mc.textRenderer.getWidth(t) / 2, y, col);
        }

        protected int tint() { return (color.get() & 0x00FFFFFF) | 0x28000000; }
    }

    /** Co so cho ESP / Hitbox: lap qua sinh vat trong tam. */
    private abstract static class EntityOverlay extends Overlay {
        protected final Setting.Num range;

        protected EntityOverlay(String name, String desc, Category cat, int argb, double defRange) {
            super(name, desc, cat, argb);
            range = add(new Setting.Num("Range", "Phạm vi (khối)", defRange, 8, 128));
        }

        @Override protected boolean singleplayerOnly() { return true; }

        protected abstract void drawEntity(DrawContext ctx, MinecraftClient mc, Projector pj,
                                           LivingEntity e, Box box, Vec3d off, int[] rect, float dist);

        @Override
        protected final void draw(DrawContext ctx, MinecraftClient mc, Projector pj) {
            float pt = SpicyClient.partialTick;
            int[] rect = new int[4];
            int drawn = 0;
            for (Entity e : mc.world.getEntities()) {
                if (drawn >= 80) break;
                if (e == mc.player || !(e instanceof LivingEntity le)) continue;
                float dist = mc.player.distanceTo(e);
                if (dist > range.f()) continue;
                Vec3d off = e.getLerpedPos(pt).subtract(e.getPos());   // noi suy cho muot
                Box box = e.getBoundingBox().offset(off);
                if (!pj.projectBox(box, rect)) continue;
                drawn++;
                drawEntity(ctx, mc, pj, le, box, off, rect, dist);
            }
        }
    }

    // ------------------------------------------------------------ Render
    public static final class EntityEsp extends EntityOverlay {
        public EntityEsp() { super("Entity ESP", "Khung và tên sinh vật quanh bạn, thấy cả sau tường (chỉ thế giới 1 người chơi).", Category.RENDER, 0xFFC77DFF, 48); }
        @Override protected void drawEntity(DrawContext ctx, MinecraftClient mc, Projector pj,
                                            LivingEntity e, Box box, Vec3d off, int[] r, float dist) {
            ctx.fill(r[0], r[1], r[2], r[3], tint());
            outline(ctx, r[0], r[1], r[2], r[3], color.get());
            String t = e.getName().getString() + "  " + String.format(Locale.ROOT, "%.0f/%.0f", e.getHealth(), e.getMaxHealth())
                    + "  " + Math.round(dist) + "m";
            label(ctx, mc, t, (r[0] + r[2]) / 2, r[1] - 10, 0xFFFFFFFF);
        }
    }

    public static final class BlockOverlay extends Overlay {
        public BlockOverlay() { super("Block Overlay", "Tô sáng khối bạn đang nhìn kèm tên, tọa độ và khoảng cách.", Category.RENDER, 0xFF60A5FA); }
        @Override protected void draw(DrawContext ctx, MinecraftClient mc, Projector pj) {
            if (!(mc.crosshairTarget instanceof BlockHitResult h) || h.getType() != HitResult.Type.BLOCK) return;
            BlockPos bp = h.getBlockPos();
            int[] r = new int[4];
            if (pj.projectBox(new Box(bp), r)) {
                ctx.fill(r[0], r[1], r[2], r[3], tint());
                outline(ctx, r[0], r[1], r[2], r[3], color.get());
            }
            String name = mc.world.getBlockState(bp).getBlock().getName().getString();
            double d = mc.player.getEyePos().distanceTo(Vec3d.ofCenter(bp));
            label(ctx, mc, name + "  " + bp.getX() + " " + bp.getY() + " " + bp.getZ() + "  "
                    + String.format(Locale.ROOT, "%.1fm", d), pj.sw / 2, pj.sh / 2 + 14, color.get());
        }
    }

    public static final class ChestDisplay extends Overlay {
        private final Setting.Num radius = add(new Setting.Num("Radius", "Bán kính quét (khối)", 12, 4, 24));
        public ChestDisplay() { super("Chest Display", "Đánh dấu rương và thùng chứa quanh bạn (chỉ thế giới 1 người chơi).", Category.RENDER, 0xFFFACC15); }
        @Override protected boolean singleplayerOnly() { return true; }
        @Override protected void draw(DrawContext ctx, MinecraftClient mc, Projector pj) {
            var res = RaidModules.scan(mc, radius.i());
            int[] r = new int[4];
            int drawn = 0;
            for (RaidModules.Found f : res.found) {
                if (drawn >= 150) break;
                if (!pj.projectBox(new Box(f.pos()), r)) continue;
                drawn++;
                ctx.fill(r[0], r[1], r[2], r[3], tint());
                outline(ctx, r[0], r[1], r[2], r[3], color.get());
                if (r[2] - r[0] >= 14) {
                    double d = mc.player.getEyePos().distanceTo(Vec3d.ofCenter(f.pos()));
                    label(ctx, mc, f.label() + " " + Math.round(d) + "m", (r[0] + r[2]) / 2, r[1] - 10, 0xFFFFFFFF);
                }
            }
        }
    }

    public static final class Waypoint extends Overlay {
        public Waypoint() { super("Waypoint", "Hiện điểm đánh dấu kèm khoảng cách. Quản lý bằng lệnh /spicy wp add|del|list <tên>.", Category.RENDER, 0xFF4ADE80); }
        @Override protected void draw(DrawContext ctx, MinecraftClient mc, Projector pj) {
            String dim = mc.world.getRegistryKey().getValue().toString();
            double[] o = new double[2];
            for (Waypoints.Wp w : Waypoints.all()) {
                if (!dim.equals(w.dim)) continue;
                if (!pj.project(w.x, w.y + 0.5, w.z, o)) continue;
                int x = (int) o[0], y = (int) o[1];
                if (x < 0 || x > pj.sw || y < 0 || y > pj.sh) continue;
                double d = mc.player.getPos().distanceTo(new Vec3d(w.x, w.y, w.z));
                ctx.fill(x - 3, y - 3, x + 3, y + 3, color.get());
                outline(ctx, x - 4, y - 4, x + 4, y + 4, 0xFFFFFFFF);
                label(ctx, mc, w.name + "  " + Math.round(d) + "m", x, y - 16, 0xFFFFFFFF);
            }
        }
    }

    // ------------------------------------------------------------ Combat
    public static final class HitboxDisplay extends EntityOverlay {
        public HitboxDisplay() { super("Hitbox Display", "Hiện khung hitbox và đường tầm mắt của sinh vật (chỉ thế giới 1 người chơi).", Category.COMBAT, 0xFFFFFFFF, 24); }
        @Override protected void drawEntity(DrawContext ctx, MinecraftClient mc, Projector pj,
                                            LivingEntity e, Box box, Vec3d off, int[] r, float dist) {
            outline(ctx, r[0], r[1], r[2], r[3], color.get());
            double[] o = new double[2];
            if (pj.project((box.minX + box.maxX) / 2, e.getEyeY() + off.y, (box.minZ + box.maxZ) / 2, o)) {
                int ey = (int) o[1];
                if (ey > r[1] && ey < r[3]) ctx.fill(r[0], ey, r[2], ey + 1, 0xFFFF5555);
            }
        }
    }

    // ------------------------------------------------------------ Utility
    /** Bat = chup 1 anh roi tu tat. Gan phim tat trong Options > Controls de chup nhanh. */
    public static final class Screenshot extends Module {
        private int wait;
        public Screenshot() { super("Screenshot", "Chụp ảnh màn hình (bật = chụp một lần rồi tự tắt). Gán phím trong Controls để chụp nhanh.", Category.UTILITY); }
        @Override protected void onEnable() { wait = 3; }
        @Override public void onTick(MinecraftClient mc) {
            if (mc.currentScreen != null) return;   // doi dong menu de anh khong dinh menu
            if (--wait > 0) return;
            try {
                ScreenshotRecorder.saveScreenshot(mc.runDirectory, mc.getFramebuffer(),
                        msg -> mc.execute(() -> { if (mc.player != null) mc.player.sendMessage(msg, false); }));
            } finally {
                setEnabled(false);
            }
        }
    }
}
