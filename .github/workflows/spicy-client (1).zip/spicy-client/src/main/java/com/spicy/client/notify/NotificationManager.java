package com.spicy.client.notify;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

import java.util.ArrayDeque;

/** Thong bao ngan o giua tren man hinh (vd khi bat/tat module). Tu mat sau ~2,5 giay. */
public final class NotificationManager {
    private record Note(String text, long until, int color) {}

    private final ArrayDeque<Note> notes = new ArrayDeque<>();
    private boolean muted;

    /** Tam tat thong bao (dung khi nap cau hinh hang loat de khong hien day thong bao). */
    public void setMuted(boolean m) { muted = m; }

    public void push(String text, int color) {
        if (muted) return;
        notes.addLast(new Note(text, System.currentTimeMillis() + 2500, color));
        while (notes.size() > 5) notes.pollFirst();
    }

    public void render(DrawContext ctx, MinecraftClient mc) {
        long now = System.currentTimeMillis();
        notes.removeIf(n -> n.until() < now);
        int sw = mc.getWindow().getScaledWidth();
        int y = 22;
        for (Note n : notes) {
            int w = mc.textRenderer.getWidth(n.text());
            int x = (sw - w) / 2;
            ctx.fill(x - 6, y - 3, x + w + 6, y + 11, 0xC0120A1E);
            ctx.fill(x - 6, y - 3, x - 4, y + 11, n.color());
            ctx.drawTextWithShadow(mc.textRenderer, n.text(), x, y, 0xFFFFFFFF);
            y += 16;
        }
    }
}
