package com.spicy.client.util;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import com.spicy.client.SpicyClient;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** Danh sach waypoint, luu o config/spicyclient/waypoints.json. Quan ly bang lenh /spicy wp ... */
public final class Waypoints {
    private Waypoints() {}

    public static final class Wp {
        public String name, dim;
        public double x, y, z;
    }

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final List<Wp> LIST = new ArrayList<>();

    private static Path file() {
        return FabricLoader.getInstance().getConfigDir().resolve("spicyclient").resolve("waypoints.json");
    }

    public static List<Wp> all() { return Collections.unmodifiableList(LIST); }

    public static void load() {
        try {
            Path f = file();
            if (!Files.exists(f)) return;
            List<Wp> l = GSON.fromJson(Files.readString(f, StandardCharsets.UTF_8), new TypeToken<List<Wp>>() {}.getType());
            LIST.clear();
            if (l != null) LIST.addAll(l);
        } catch (IOException | RuntimeException e) {
            SpicyClient.LOGGER.error("Doc waypoints that bai", e);
        }
    }

    private static void save() {
        try {
            Path f = file();
            Files.createDirectories(f.getParent());
            Files.writeString(f, GSON.toJson(LIST), StandardCharsets.UTF_8);
        } catch (IOException e) {
            SpicyClient.LOGGER.error("Luu waypoints that bai", e);
        }
    }

    /** Them moi, hoac cap nhat neu da co waypoint cung ten trong cung the gioi. */
    public static void add(String name, String dim, double x, double y, double z) {
        remove(name, dim, false);
        Wp w = new Wp();
        w.name = name; w.dim = dim; w.x = x; w.y = y; w.z = z;
        LIST.add(w);
        save();
    }

    public static boolean remove(String name, String dim) { return remove(name, dim, true); }

    private static boolean remove(String name, String dim, boolean persist) {
        boolean removed = LIST.removeIf(w -> w.name.equalsIgnoreCase(name) && w.dim.equals(dim));
        if (removed && persist) save();
        return removed;
    }
}
