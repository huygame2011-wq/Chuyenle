package com.spicy.client.module.raid;

import com.spicy.client.module.Category;
import com.spicy.client.module.hud.HudModule;
import com.spicy.client.setting.Setting;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.ChestBlock;
import net.minecraft.block.ShulkerBoxBlock;
import net.minecraft.block.enums.ChestType;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import com.spicy.client.util.SchematicReader;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Phan tich cong trinh tren ban do CUA BAN.
 * Chi quet khi ban dang o the gioi 1 nguoi choi (singleplayer / ban do ban so huu).
 * Chi quet cac khoi quanh nguoi choi trong ban kinh nho, khong tu dong do tim hay tac dong vao thu gi.
 */
public final class RaidModules {
    private RaidModules() {}

    /** Ket qua mot lan quet. */
    /** Vi tri mot thung chua tim thay. */
    public record Found(BlockPos pos, String label) {}

    public static final class Result {
        public final List<Found> found = new ArrayList<>();
        final Map<Block, Integer> counts = new HashMap<>();
        long total;
        int chests, trapped, ender, barrels, shulkers, furnaces, hoppers, dispensers, droppers;
        public int radius;
        int containers() { return chests + trapped + ender + barrels + shulkers + furnaces + hoppers + dispensers + droppers; }
    }

    private static final Map<Integer, Result> CACHE = new HashMap<>();
    private static final Map<Integer, Long> TIME = new HashMap<>();

    /** Quet (co cache 3 giay de khong ton hieu nang khi nhieu module cung dung). */
    public static Result scan(MinecraftClient mc, int radius) {
        long now = System.currentTimeMillis();
        Result cached = CACHE.get(radius);
        if (cached != null && now - TIME.get(radius) < 3000) return cached;

        Result r = new Result();
        r.radius = radius;
        var world = mc.world;
        var p = mc.player;
        int vr = Math.min(radius, 16);
        int cx = p.getBlockX(), cy = p.getBlockY(), cz = p.getBlockZ();
        BlockPos.Mutable pos = new BlockPos.Mutable();
        for (int dx = -radius; dx <= radius; dx++) {
            for (int dz = -radius; dz <= radius; dz++) {
                for (int dy = -vr; dy <= vr; dy++) {
                    int y = cy + dy;
                    if (world.isOutOfHeightLimit(y)) continue;
                    pos.set(cx + dx, y, cz + dz);
                    BlockState st = world.getBlockState(pos);
                    if (st.isAir()) continue;
                    Block b = st.getBlock();
                    r.total++;
                    r.counts.merge(b, 1, Integer::sum);
                    String label = null;
                    if (b == Blocks.CHEST || b == Blocks.TRAPPED_CHEST) {
                        ChestType t = st.get(ChestBlock.CHEST_TYPE);
                        if (t != ChestType.RIGHT) { // ruong doi chi dem 1 lan
                            if (b == Blocks.CHEST) { r.chests++; label = "Rương"; }
                            else { r.trapped++; label = "Rương bẫy"; }
                        }
                    } else if (b == Blocks.ENDER_CHEST) { r.ender++; label = "Rương Ender"; }
                    else if (b == Blocks.BARREL) { r.barrels++; label = "Thùng gỗ"; }
                    else if (b instanceof ShulkerBoxBlock) { r.shulkers++; label = "Shulker"; }
                    else if (b == Blocks.FURNACE || b == Blocks.BLAST_FURNACE || b == Blocks.SMOKER) { r.furnaces++; label = "Lò"; }
                    else if (b == Blocks.HOPPER) { r.hoppers++; label = "Phễu"; }
                    else if (b == Blocks.DISPENSER) { r.dispensers++; label = "Máy phát"; }
                    else if (b == Blocks.DROPPER) { r.droppers++; label = "Máy thả"; }
                    if (label != null && r.found.size() < 400) r.found.add(new Found(pos.toImmutable(), label));
                }
            }
        }
        CACHE.put(radius, r);
        TIME.put(radius, now);
        return r;
    }

    /** Co so: kiem tra singleplayer, quet, roi ve cac dong mo ta. */
    private abstract static class Scanning extends HudModule {
        protected final Setting.Num radius = add(new Setting.Num("Radius", "Bán kính quét (khối)", 12, 4, 24));

        protected Scanning(String name, String desc, int x, int y) {
            super(name, desc, Category.RAID_ANALYSIS, x, y);
        }

        protected abstract List<String> describe(Result r);

        @Override
        protected final void renderContent(DrawContext ctx, MinecraftClient mc) {
            if (mc.player == null || mc.world == null) return;
            if (!mc.isInSingleplayer()) {
                lines(ctx, mc, "Chỉ quét được trong thế giới", "1 người chơi (bản đồ của bạn).");
                return;
            }
            lines(ctx, mc, describe(scan(mc, radius.i())).toArray(new String[0]));
        }
    }

    private static String n(String label, long v) { return label + ": " + v; }

    public static final class BaseScanner extends Scanning {
        public BaseScanner() { super("Base Scanner", "Tóm tắt công trình quanh bạn: tổng khối, rương và thùng chứa (chỉ bản đồ của bạn).", 200, 4); }
        @Override protected List<String> describe(Result r) {
            return List.of(
                    "Quét bán kính " + r.radius + " khối",
                    n("Tổng khối", r.total),
                    n("Loại khối", r.counts.size()),
                    n("Rương", r.chests + r.trapped),
                    n("Thùng chứa (tổng)", r.containers()));
        }
    }

    public static final class BlockCounter extends Scanning {
        private final Setting.Num top = add(new Setting.Num("Top", "Số loại khối hiển thị", 5, 3, 10));
        public BlockCounter() { super("Block Counter", "Đếm các loại khối nhiều nhất quanh bạn (chỉ bản đồ của bạn).", 200, 64); }
        @Override protected List<String> describe(Result r) {
            List<Map.Entry<Block, Integer>> es = new ArrayList<>(r.counts.entrySet());
            es.sort((a, b) -> b.getValue() - a.getValue());
            List<String> out = new ArrayList<>();
            out.add(n("Tổng khối", r.total));
            for (int i = 0; i < Math.min(top.i(), es.size()); i++)
                out.add(es.get(i).getKey().getName().getString() + ": " + es.get(i).getValue());
            return out;
        }
    }

    public static final class ChestCounter extends Scanning {
        public ChestCounter() { super("Chest Counter", "Đếm rương thường, rương bẫy và rương Ender quanh bạn (chỉ bản đồ của bạn).", 200, 140); }
        @Override protected List<String> describe(Result r) {
            return List.of(n("Rương", r.chests), n("Rương bẫy", r.trapped), n("Rương Ender", r.ender));
        }
    }

    public static final class ContainerStats extends Scanning {
        public ContainerStats() { super("Container Statistics", "Thống kê các loại thùng chứa: rương, thùng, shulker, lò, phễu... (chỉ bản đồ của bạn).", 200, 176); }
        @Override protected List<String> describe(Result r) {
            return List.of(
                    n("Rương", r.chests), n("Rương bẫy", r.trapped), n("Rương Ender", r.ender),
                    n("Thùng gỗ", r.barrels), n("Hộp Shulker", r.shulkers), n("Lò", r.furnaces),
                    n("Phễu", r.hoppers), n("Máy phát", r.dispensers), n("Máy thả", r.droppers),
                    n("Tổng", r.containers()));
        }
    }

    /** Chi toa do, khoang cach va huong toi thung chua gan nhat (chi ban do cua ban). */
    public static final class NearestContainer extends Scanning {
        public NearestContainer() { super("Nearest Container", "Chỉ tọa độ, khoảng cách và hướng tới rương/thùng chứa gần nhất (chỉ bản đồ của bạn).", 200, 230); }
        @Override protected List<String> describe(Result r) {
            var p = MinecraftClient.getInstance().player;
            Found best = null;
            double bd = Double.MAX_VALUE;
            for (Found f : r.found) {
                double dx = f.pos().getX() + 0.5 - p.getX(), dy = f.pos().getY() + 0.5 - p.getY(), dz = f.pos().getZ() + 0.5 - p.getZ();
                double d = dx * dx + dy * dy + dz * dz;
                if (d < bd) { bd = d; best = f; }
            }
            if (best == null) return List.of("Không có thùng chứa", "trong bán kính " + r.radius + " khối");
            double dx = best.pos().getX() + 0.5 - p.getX(), dz = best.pos().getZ() + 0.5 - p.getZ();
            double target = Math.toDegrees(Math.atan2(-dx, dz));
            float delta = MathHelper.wrapDegrees((float) (target - p.getYaw()));
            String dir = Math.abs(delta) < 20 ? "Phía trước" : Math.abs(delta) > 160 ? "Phía sau" : delta > 0 ? "Bên phải" : "Bên trái";
            int dyI = best.pos().getY() - p.getBlockY();
            return List.of(
                    "Gần nhất: " + best.label(),
                    "Tọa độ: " + best.pos().getX() + " " + best.pos().getY() + " " + best.pos().getZ(),
                    String.format(Locale.ROOT, "Cách: %.1f khối", Math.sqrt(bd)),
                    "Hướng: " + dir + "  (cao " + (dyI >= 0 ? "+" : "") + dyI + ")");
        }
    }

    /**
     * Xem thong tin ban ve .schem / .litematic: kich thuoc va vat lieu can dung.
     * Bo file vao thu muc .minecraft/spicyclient/schematics. (Chi doc thong tin, khong dat khoi.)
     */
    public static final class SchematicViewer extends HudModule {
        private final Setting.Num index = add(new Setting.Num("Index", "Chọn bản vẽ số", 1, 1, 50));
        private final Setting.Num top = add(new Setting.Num("Top", "Số vật liệu hiển thị", 6, 3, 12));
        private final Map<String, SchematicReader.Info> cache = new ConcurrentHashMap<>();
        private final Set<String> loading = ConcurrentHashMap.newKeySet();

        public SchematicViewer() { super("Schematic Viewer", "Đọc bản vẽ .schem/.litematic: kích thước và danh sách vật liệu.", Category.RAID_ANALYSIS, 330, 4); }

        @Override protected void renderContent(DrawContext ctx, MinecraftClient mc) {
            Path dir = mc.runDirectory.toPath().resolve("spicyclient").resolve("schematics");
            List<Path> files = new ArrayList<>();
            try {
                Files.createDirectories(dir);
                try (var s = Files.list(dir)) {
                    s.filter(f -> { String n = f.getFileName().toString().toLowerCase(Locale.ROOT); return n.endsWith(".schem") || n.endsWith(".litematic"); })
                     .sorted().forEach(files::add);
                }
            } catch (Exception e) {
                lines(ctx, mc, "Không đọc được thư mục bản vẽ");
                return;
            }
            if (files.isEmpty()) {
                lines(ctx, mc, "Bỏ file .schem/.litematic vào:", ".minecraft/spicyclient/schematics");
                return;
            }
            int i = Math.min(index.i(), files.size()) - 1;
            Path f = files.get(i);
            long mod = f.toFile().lastModified();
            String key = f + "|" + mod;
            SchematicReader.Info info = cache.get(key);
            if (info == null) {
                if (loading.add(key)) {
                    Thread t = new Thread(() -> { cache.put(key, SchematicReader.read(f)); loading.remove(key); }, "spicy-schematic");
                    t.setDaemon(true);
                    t.start();
                }
                lines(ctx, mc, "Bản vẽ [" + (i + 1) + "/" + files.size() + "]: " + f.getFileName(), "Đang đọc...");
                return;
            }
            if (info.error != null) {
                lines(ctx, mc, "Bản vẽ [" + (i + 1) + "/" + files.size() + "]: " + info.name, info.error);
                return;
            }
            List<Map.Entry<String, Integer>> es = new ArrayList<>(info.materials.entrySet());
            es.sort((a, b) -> b.getValue() - a.getValue());
            List<String> out = new ArrayList<>();
            out.add("Bản vẽ [" + (i + 1) + "/" + files.size() + "]: " + info.name);
            out.add("Kích thước: " + info.w + " x " + info.h + " x " + info.l);
            out.add(n("Tổng khối", info.total));
            for (int k = 0; k < Math.min(top.i(), es.size()); k++) out.add(es.get(k).getKey() + ": " + es.get(k).getValue());
            lines(ctx, mc, out.toArray(new String[0]));
        }
    }
}
