package com.spicy.client.module.hud;

import com.spicy.client.module.Category;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

public class FpsHud extends HudModule {
    public FpsHud() {
        super("FPS", "Hiển thị số khung hình mỗi giây (FPS).", Category.UTILITY, 4, 4);
    }

    @Override
    protected void renderContent(DrawContext ctx, MinecraftClient mc) {
        ctx.drawTextWithShadow(mc.textRenderer, mc.getCurrentFps() + " FPS", 0, 0, color.get());
    }
}
