package com.spicy.client.setting;

import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;

/** Co so cho moi cai dat. name = khoa luu config (khong doi), label = ten hien thi tieng Viet. */
public abstract class Setting<T> {
    private final String name;
    private final String label;
    protected T value;
    private final T defaultValue;

    protected Setting(String name, String label, T defaultValue) {
        this.name = name;
        this.label = label;
        this.value = defaultValue;
        this.defaultValue = defaultValue;
    }

    public String getName() { return name; }
    public String getLabel() { return label; }
    public T get() { return value; }
    public void set(T v) { this.value = v; }
    public void reset() { this.value = defaultValue; }

    public abstract JsonElement toJson();
    public abstract void fromJson(JsonElement e);

    public static final class Bool extends Setting<Boolean> {
        public Bool(String name, String label, boolean def) { super(name, label, def); }
        @Override public JsonElement toJson() { return new JsonPrimitive(value); }
        @Override public void fromJson(JsonElement e) { value = e.getAsBoolean(); }
    }

    public static final class Num extends Setting<Double> {
        public final double min, max;
        public Num(String name, String label, double def, double min, double max) {
            super(name, label, def);
            this.min = min;
            this.max = max;
        }
        @Override public void set(Double v) { value = Math.max(min, Math.min(max, v)); }
        @Override public JsonElement toJson() { return new JsonPrimitive(value); }
        @Override public void fromJson(JsonElement e) { set(e.getAsDouble()); }
        public float f() { return value.floatValue(); }
        public int i() { return value.intValue(); }
    }

    /** Mau ARGB, vd 0xFFAA55FF. */
    public static final class Color extends Setting<Integer> {
        public Color(String name, String label, int argb) { super(name, label, argb); }
        @Override public JsonElement toJson() { return new JsonPrimitive(value); }
        @Override public void fromJson(JsonElement e) { value = e.getAsInt(); }
    }

    /** Danh sach lua chon (dropdown): bam de chuyen sang lua chon ke tiep. Luu vao config dang chuoi. */
    public static final class Mode extends Setting<Integer> {
        private final String[] options;
        public Mode(String name, String label, String[] options, int def) {
            super(name, label, def);
            this.options = options;
        }
        public String current() { return options[value]; }
        public String[] options() { return options; }
        public int index() { return value; }
        public void next() { value = (value + 1) % options.length; }
        @Override public JsonElement toJson() { return new JsonPrimitive(options[value]); }
        @Override public void fromJson(JsonElement e) {
            String n = e.getAsString();
            for (int i = 0; i < options.length; i++) if (options[i].equals(n)) { value = i; return; }
        }
    }
}
