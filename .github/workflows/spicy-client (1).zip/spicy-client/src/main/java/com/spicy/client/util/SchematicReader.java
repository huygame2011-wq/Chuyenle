package com.spicy.client.util;

import java.nio.file.Path;
import java.util.*;

/** Doc thong tin ban ve: kich thuoc va vat lieu. Ho tro .schem (Sponge v2/v3) va .litematic. */
public final class SchematicReader {
    private SchematicReader() {}

    public static final class Info {
        public String name = "";
        public int w, h, l;
        public long total;              // so khoi khong phai khong khi
        public Map<String, Integer> materials = new HashMap<>();
        public String error;
    }

    public static Info read(Path file) {
        Info info = new Info();
        info.name = file.getFileName().toString();
        try {
            Map<String, Object> root = Nbt.readFile(file);
            String n = info.name.toLowerCase(Locale.ROOT);
            if (n.endsWith(".litematic")) litematic(root, info);
            else if (n.endsWith(".schem")) sponge(root, info);
            else info.error = "Chi ho tro .schem va .litematic";
        } catch (Exception e) {
            info.error = "Loi doc file: " + e.getMessage();
        }
        return info;
    }

    // ------------------------------------------------------------ Sponge .schem
    @SuppressWarnings("unchecked")
    private static void sponge(Map<String, Object> root, Info info) {
        Map<String, Object> s = root.containsKey("Schematic") ? (Map<String, Object>) root.get("Schematic") : root;
        info.w = num(s.get("Width")); info.h = num(s.get("Height")); info.l = num(s.get("Length"));
        Map<String, Object> palette;
        byte[] data;
        if (s.containsKey("Blocks")) { // v3
            Map<String, Object> b = (Map<String, Object>) s.get("Blocks");
            palette = (Map<String, Object>) b.get("Palette");
            data = (byte[]) b.get("Data");
        } else {                       // v2
            palette = (Map<String, Object>) s.get("Palette");
            data = (byte[]) s.get("BlockData");
        }
        if (palette == null || data == null) { info.error = "Khong tim thay palette/du lieu khoi"; return; }
        String[] names = new String[palette.size() + 1];
        int maxId = 0;
        Map<Integer, String> byId = new HashMap<>();
        for (Map.Entry<String, Object> e : palette.entrySet()) {
            int id = num(e.getValue());
            byId.put(id, clean(e.getKey()));
            maxId = Math.max(maxId, id);
        }
        long[] counts = new long[maxId + 1];
        int i = 0;
        while (i < data.length) {              // giai ma varint
            int value = 0, shift = 0, b;
            do {
                b = data[i++] & 0xFF;
                value |= (b & 0x7F) << shift;
                shift += 7;
            } while ((b & 0x80) != 0 && i < data.length);
            if (value >= 0 && value < counts.length) counts[value]++;
        }
        for (int id = 0; id < counts.length; id++) {
            String nm = byId.get(id);
            if (nm == null || counts[id] == 0 || isAir(nm)) continue;
            info.materials.merge(nm, (int) counts[id], Integer::sum);
            info.total += counts[id];
        }
    }

    // ------------------------------------------------------------ .litematic
    @SuppressWarnings("unchecked")
    private static void litematic(Map<String, Object> root, Info info) {
        Map<String, Object> regions = (Map<String, Object>) root.get("Regions");
        if (regions == null) { info.error = "Khong tim thay Regions"; return; }
        int maxW = 0, maxH = 0, maxL = 0;
        for (Object ro : regions.values()) {
            Map<String, Object> r = (Map<String, Object>) ro;
            Map<String, Object> size = (Map<String, Object>) r.get("Size");
            int sx = Math.abs(num(size.get("x"))), sy = Math.abs(num(size.get("y"))), sz = Math.abs(num(size.get("z")));
            maxW = Math.max(maxW, sx); maxH = Math.max(maxH, sy); maxL = Math.max(maxL, sz);
            List<Object> pal = (List<Object>) r.get("BlockStatePalette");
            long[] states = (long[]) r.get("BlockStates");
            if (pal == null || states == null) continue;
            int bits = Math.max(2, 32 - Integer.numberOfLeadingZeros(pal.size() - 1));
            long mask = (1L << bits) - 1;
            long volume = (long) sx * sy * sz;
            long[] counts = new long[pal.size()];
            for (long idx = 0; idx < volume; idx++) {
                long bit = idx * bits;
                int li = (int) (bit >>> 6), off = (int) (bit & 63);
                long v = states[li] >>> off;
                if (off + bits > 64 && li + 1 < states.length) v |= states[li + 1] << (64 - off);
                int id = (int) (v & mask);
                if (id < counts.length) counts[id]++;
            }
            for (int id = 0; id < counts.length; id++) {
                String nm = clean((String) ((Map<String, Object>) pal.get(id)).get("Name"));
                if (counts[id] == 0 || isAir(nm)) continue;
                info.materials.merge(nm, (int) counts[id], Integer::sum);
                info.total += counts[id];
            }
        }
        info.w = maxW; info.h = maxH; info.l = maxL;
    }

    private static int num(Object o) { return o instanceof Number n ? n.intValue() : 0; }

    private static boolean isAir(String n) { return n.equals("air") || n.equals("cave_air") || n.equals("void_air"); }

    /** "minecraft:oak_stairs[facing=north]" -> "oak_stairs" */
    private static String clean(String s) {
        int b = s.indexOf('[');
        if (b >= 0) s = s.substring(0, b);
        int c = s.indexOf(':');
        return c >= 0 ? s.substring(c + 1) : s;
    }
}
