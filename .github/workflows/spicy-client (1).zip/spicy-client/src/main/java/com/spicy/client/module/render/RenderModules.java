package com.spicy.client.module.render;

import com.spicy.client.module.Category;
import com.spicy.client.module.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;

public final class RenderModules {
    private RenderModules() {}

    /** Sang toan bo bang hieu ung Night Vision phia client (khong gui gi len server). */
    public static final class Fullbright extends Module {
        private static final int LONG = 100000;
        public Fullbright() { super("Fullbright", "Nhìn rõ trong bóng tối (dùng hiệu ứng nhìn đêm phía client, tự gỡ khi tắt).", Category.RENDER); }

        @Override public void onTick(MinecraftClient mc) {
            var p = mc.player;
            if (p == null) return;
            if (!p.hasStatusEffect(StatusEffects.NIGHT_VISION)) {
                p.addStatusEffect(new StatusEffectInstance(StatusEffects.NIGHT_VISION, LONG, 0, false, false, false));
            }
        }

        @Override protected void onDisable() {
            var p = MinecraftClient.getInstance().player;
            if (p == null) return;
            StatusEffectInstance e = p.getStatusEffect(StatusEffects.NIGHT_VISION);
            // chi go hieu ung do module nay them (thoi gian rat dai), khong dong vao thuoc that
            if (e != null && e.getDuration() > LONG / 2) p.removeStatusEffect(StatusEffects.NIGHT_VISION);
        }
    }
}
