package com.spicy.client;

import com.mojang.brigadier.Command;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.spicy.client.config.ConfigManager;
import com.spicy.client.gui.ClickGuiScreen;
import com.spicy.client.module.ModuleManager;
import com.spicy.client.notify.NotificationManager;
import com.spicy.client.util.Waypoints;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.command.v2.FabricClientCommandSource;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.minecraft.client.MinecraftClient;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class SpicyClient implements ClientModInitializer {
    public static final String MOD_ID = "spicyclient";
    public static final Logger LOGGER = LoggerFactory.getLogger("SpicyClient");

    public static ModuleManager modules;
    public static ConfigManager config;
    public static NotificationManager notifications;
    /** Tien do giua 2 tick cua frame hien tai (dung de noi suy overlay cho muot). */
    public static float partialTick;

    @Override
    public void onInitializeClient() {
        LOGGER.info("[Spicy Client] Bat dau khoi dong...");
        notifications = new NotificationManager();
        modules = new ModuleManager();
        modules.init();
        config = new ConfigManager(modules);
        // Nap cau hinh sau khi client khoi dong xong: luc nay GameOptions da san sang.
        ClientLifecycleEvents.CLIENT_STARTED.register(c -> { config.init(); Waypoints.load(); });

        ClientTickEvents.END_CLIENT_TICK.register(modules::tick);
        HudElementRegistry.addLast(Identifier.of(MOD_ID, "hud"),
                (ctx, tickCounter) -> {
                    partialTick = tickCounter.getTickProgress(false);
                    modules.renderHud(ctx, MinecraftClient.getInstance());
                });
        ClientLifecycleEvents.CLIENT_STOPPING.register(c -> { config.save(); modules.shutdown(); });

        // Lenh /spicy (mo menu) va /spicy wp add|del|list <ten> (quan ly waypoint).
        Command<FabricClientCommandSource> open = c -> {
            MinecraftClient mc = c.getSource().getClient();
            mc.send(() -> mc.setScreen(new ClickGuiScreen())); // tri hoan de khong bi dong cung o chat
            return Command.SINGLE_SUCCESS;
        };
        Command<FabricClientCommandSource> wpAdd = c -> {
            var src = c.getSource();
            var pl = src.getPlayer();
            String name = StringArgumentType.getString(c, "name");
            Waypoints.add(name, src.getWorld().getRegistryKey().getValue().toString(), pl.getX(), pl.getY(), pl.getZ());
            src.sendFeedback(Text.literal("Đã lưu waypoint '" + name + "' tại vị trí của bạn."));
            return Command.SINGLE_SUCCESS;
        };
        Command<FabricClientCommandSource> wpDel = c -> {
            var src = c.getSource();
            String name = StringArgumentType.getString(c, "name");
            boolean ok = Waypoints.remove(name, src.getWorld().getRegistryKey().getValue().toString());
            src.sendFeedback(Text.literal(ok ? "Đã xóa waypoint '" + name + "'." : "Không có waypoint '" + name + "' ở thế giới này."));
            return Command.SINGLE_SUCCESS;
        };
        Command<FabricClientCommandSource> wpList = c -> {
            var src = c.getSource();
            String dim = src.getWorld().getRegistryKey().getValue().toString();
            int n = 0;
            for (Waypoints.Wp w : Waypoints.all()) {
                if (!dim.equals(w.dim)) continue;
                n++;
                src.sendFeedback(Text.literal(w.name + ": " + Math.round(w.x) + " " + Math.round(w.y) + " " + Math.round(w.z)));
            }
            if (n == 0) src.sendFeedback(Text.literal("Chưa có waypoint nào ở thế giới này."));
            return Command.SINGLE_SUCCESS;
        };
        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) ->
                dispatcher.register(ClientCommandManager.literal("spicy").executes(open)
                        .then(ClientCommandManager.literal("wp")
                                .then(ClientCommandManager.literal("add")
                                        .then(ClientCommandManager.argument("name", StringArgumentType.word()).executes(wpAdd)))
                                .then(ClientCommandManager.literal("del")
                                        .then(ClientCommandManager.argument("name", StringArgumentType.word()).executes(wpDel)))
                                .then(ClientCommandManager.literal("list").executes(wpList)))));

        // Thong bao khi vao the gioi de xac nhan mod da duoc tai.
        ClientPlayConnectionEvents.JOIN.register((handler, sender, client) -> client.execute(() -> {
            if (client.player != null) {
                client.player.sendMessage(Text.literal(
                        "§d[Spicy Client]§r đã tải. Nhấn §eRight Shift§r hoặc gõ §e/spicy§r để mở menu."), false);
            }
        }));

        LOGGER.info("[Spicy Client] Da khoi dong xong, {} module. Phim mo menu: Right Shift, hoac lenh /spicy", modules.all().size());
    }
}
