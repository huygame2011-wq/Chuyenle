package com.spicy.client.util;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;
import java.util.zip.GZIPInputStream;

/** Bo doc NBT toi thieu. Compound->Map, List->List, mang -> byte[]/int[]/long[], so -> Number, chuoi -> String. */
public final class Nbt {
    private Nbt() {}

    @SuppressWarnings("unchecked")
    public static Map<String, Object> readFile(Path p) throws IOException {
        byte[] raw = Files.readAllBytes(p);
        InputStream in = new ByteArrayInputStream(raw);
        if (raw.length > 2 && (raw[0] & 0xFF) == 0x1F && (raw[1] & 0xFF) == 0x8B) in = new GZIPInputStream(in);
        try (DataInputStream d = new DataInputStream(new BufferedInputStream(in))) {
            int type = d.readUnsignedByte();
            if (type != 10) throw new IOException("Goc NBT khong phai compound");
            d.readUTF();
            return (Map<String, Object>) read(d, 10, 0);
        }
    }

    private static Object read(DataInputStream d, int type, int depth) throws IOException {
        if (depth > 64) throw new IOException("NBT long qua sau");
        switch (type) {
            case 1: return d.readByte();
            case 2: return d.readShort();
            case 3: return d.readInt();
            case 4: return d.readLong();
            case 5: return d.readFloat();
            case 6: return d.readDouble();
            case 7: { int n = d.readInt(); check(n); byte[] a = new byte[n]; d.readFully(a); return a; }
            case 8: return d.readUTF();
            case 9: {
                int t = d.readUnsignedByte(), n = d.readInt(); check(n);
                List<Object> l = new ArrayList<>();
                for (int i = 0; i < n; i++) l.add(read(d, t, depth + 1));
                return l;
            }
            case 10: {
                Map<String, Object> m = new LinkedHashMap<>();
                while (true) {
                    int t = d.readUnsignedByte();
                    if (t == 0) break;
                    String name = d.readUTF();
                    m.put(name, read(d, t, depth + 1));
                }
                return m;
            }
            case 11: { int n = d.readInt(); check(n); int[] a = new int[n]; for (int i = 0; i < n; i++) a[i] = d.readInt(); return a; }
            case 12: { int n = d.readInt(); check(n); long[] a = new long[n]; for (int i = 0; i < n; i++) a[i] = d.readLong(); return a; }
            default: throw new IOException("Kieu NBT la: " + type);
        }
    }

    private static void check(int n) throws IOException {
        if (n < 0 || n > 200_000_000) throw new IOException("Do dai mang NBT bat thuong");
    }
}
