package com.spicy.client.module;

import com.spicy.client.SpicyClient;
import com.spicy.client.setting.Setting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public abstract class Module {
    private final String name;
    private final String description;
    private final Category category;
    private boolean enabled;
    private final List<Setting<?>> settings = new ArrayList<>();

    protected Module(String name, String description, Category category) {
        this.name = name;
        this.description = description;
        this.category = category;
    }

    public String getName() { return name; }
    /** Id on dinh dung cho config / keybind. */
    public String getId() { return name.toLowerCase().replaceAll("[^a-z0-9]", ""); }
    public String getDescription() { return description; }
    public Category getCategory() { return category; }
    public boolean isEnabled() { return enabled; }
    public List<Setting<?>> getSettings() { return Collections.unmodifiableList(settings); }

    protected <S extends Setting<?>> S add(S s) { settings.add(s); return s; }

    public void toggle() { setEnabled(!enabled); }

    /** Bat/tat an toan: loi trong onEnable/onDisable khong lam crash game. */
    public void setEnabled(boolean value) {
        if (value == enabled) return;
        enabled = value;
        try {
            if (value) onEnable(); else onDisable();
        } catch (Throwable t) {
            SpicyClient.LOGGER.error("Module {} loi khi doi trang thai, tu dong tat", name, t);
            enabled = false;
            if (SpicyClient.notifications != null) SpicyClient.notifications.push(name + ": lỗi, đã tự tắt", 0xFFF87171);
            return;
        }
        if (SpicyClient.notifications != null)
            SpicyClient.notifications.push(name + (value ? " đã bật" : " đã tắt"), value ? 0xFF4ADE80 : 0xFFF87171);
    }

    protected void onEnable() {}
    protected void onDisable() {}
    /** Goi khi thoat game (sau khi da luu cau hinh) de tra lai cai dat cua game ma module da doi. */
    public void onShutdown() {}
    /** Goi moi client tick khi module dang bat. */
    public void onTick(MinecraftClient mc) {}
    /** Goi moi frame HUD khi module dang bat. */
    public void onHudRender(DrawContext ctx, MinecraftClient mc) {}
}
