# Huong dan build JAR va cai dat

## A. Build bang GitHub (khong can may tinh)
1. Tao repo tren github.com. Tao file `.github/workflows/build.yml` (noi dung trong thu muc `.github` cua project; neu duoc, tai thang file zip nay len repo ten `spicy-client.zip`).
2. Tab **Actions** > chay **Build Spicy Client**. Cho dau tich xanh.
3. Mo luot chay > muc **Artifacts** > tai **spicy-client-jar** (la file zip), giai nen duoc `spicy-client-0.1.0.jar`.

## B. Build tren may tinh
Can JDK 21 va Gradle 9: `gradle build` -> `build/libs/spicy-client-0.1.0.jar` (khong lay file `-sources`).
Cap nhat so phien ban trong `gradle.properties` theo https://fabricmc.net/develop (chon 1.21.11).

## C. Cai vao Minecraft
1. Cai Fabric Loader cho 1.21.11 (PC: fabricmc.net/use; dien thoai: cai Fabric trong MojoLauncher).
2. Bo vao thu muc `mods`: **Fabric API (ban 1.21.11)** va **spicy-client-0.1.0.jar**.
3. Chay game. Vao the gioi se thay dong chat "[Spicy Client] da tai". Mo menu: **Right Shift** hoac lenh `/spicy`.

## D. Kiem tra tung nhom
- HUD (FPS, Ping, CPS, Coordinates, Clock, Module List...): bat trong menu, kiem tra hien dung, keo thanh truot X/Y/Scale.
- Movement: Sprint, Toggle Sneak, Auto Jump, Speed Display, Direction HUD.
- Render/Raid/Combat overlay: thu trong the gioi 1 nguoi choi cua ban (ESP, Hitbox, Chest Display, quet can cu chi chay o do).
- Waypoint: `/spicy wp add test`, nhin ve huong do, `/spicy wp list`, `/spicy wp del test`.
- Schematic Viewer: bo file .schem/.litematic vao `.minecraft/spicyclient/schematics`.
- Auto Respawn: chet trong the gioi cua ban, kiem tra tu hoi sinh.
Neu loi: gui `logs/latest.log`.
