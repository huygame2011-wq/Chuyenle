# Nguyen ly hoat dong (Spicy Client)

1. **Kien truc**: `SpicyClient` (ClientInitializer) tao NotificationManager, ModuleManager, ConfigManager va gan vao cac su kien cua Fabric. Moi chuc nang la mot lop `Module` doc lap.
2. **Dang ky module**: `ModuleManager.init()` goi `register(new ...)`. Moi module duoc them vao danh sach va duoc cap san 1 phim tat (KeyBinding) trong Options > Controls.
3. **Bat/tat**: `Module.setEnabled()` goi `onEnable()/onDisable()` trong try/catch. Neu loi, module tu tat va ghi log, game khong crash. Moi lan doi trang thai deu co thong bao.
4. **Su kien**: dung truc tiep su kien Fabric (`END_CLIENT_TICK`, `HudElementRegistry`, `CLIENT_STARTED`, `CLIENT_STOPPING`, lenh client). `ModuleManager` phan phoi `onTick` va `onHudRender` cho tung module dang bat. Chua co lop EventManager rieng vi chua co module nao can su kien khac; se them khi co module can (vd. su kien chat/goi tin).
5. **Nhan du lieu**: module doc `MinecraftClient` (nguoi choi, the gioi, tuy chon) trong `onTick`/`onHudRender`, luon kiem tra null.
6. **Ve HUD**: `HudModule` ve noi dung tai goc (0,0); he thong tu tinh vi tri X/Y va kich thuoc roi ve. Cac overlay trong the gioi dung `Projector` chieu toa do 3D sang toa do man hinh.
7. **Luu cau hinh**: `ConfigManager` luu JSON theo profile (`config/spicyclient/profiles/*.json`): bat/tat va moi `Setting`. Waypoint luu rieng (`waypoints.json`).
8. **Phim tat**: moi module co KeyBinding vanilla; mo menu bang Right Shift hoac lenh `/spicy`.
9. **Giam lag**: module tat thi khong chay; quet khoi co cache 3 giay va gioi han ban kinh; ESP gioi han so doi tuong ve; bo doc ban ve chay o luong rieng.
10. **Kiem tra loi**: loi trong module bi bat va ghi log, module tu tat; kiem tra null; thong tin loi o `logs/latest.log`.
11. **Build JAR**: xem `docs/HUONG_DAN.md`.
12. **Cai dat**: xem `docs/HUONG_DAN.md`.

## Doi chieu voi bo lop ban yeu cau
ClientInitializer = SpicyClient | ModuleManager | Module | ModuleCategory = Category | Setting | ClickGUI = ClickGuiScreen |
HUDManager = HudModule + ModuleManager.renderHud | ConfigManager | RenderManager = Projector + OverlayModules |
KeybindManager = KeyBinding trong ModuleManager | NotificationManager | EventManager = chua tach rieng (xem muc 4).
