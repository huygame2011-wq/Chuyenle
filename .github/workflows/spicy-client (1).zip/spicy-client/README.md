# Spicy Client (Giai doan 1: nen tang)

Yeu cau: JDK 21, Gradle 9.x (hoac dung wrapper), Minecraft 1.21.11, Fabric Loader.

## Build
1. Mo https://fabricmc.net/develop, chon 1.21.11, copy dung so phien ban vao `gradle.properties`.
2. Tao wrapper (1 lan): `gradle wrapper --gradle-version 9.2.0`
3. Build: `./gradlew build` (Windows: `gradlew.bat build`)
4. JAR nam o `build/libs/spicy-client-0.1.0.jar` (khong lay file `-sources`).

## Cai dat
Cai Fabric Loader + Fabric API cho 1.21.11, copy JAR vao `.minecraft/mods`.

## Hien co (GD1)
- He thong Module (bat/tat an toan, setting, loi tu tat chu khong crash)
- Phim tat tung module: Options > Controls > "Spicy Client"
- Luu cau hinh + nhieu profile: `.minecraft/config/spicyclient/profiles/*.json`
- Module FPS (HUD, chinh X/Y/Scale/Color qua file profile den khi co ClickGUI o GD3)

## Giai doan 3 (ban dau): Menu tieng Viet
- Mo/dong menu: **Right Shift** (doi trong Options > Controls > "Spicy Client").
- Tim kiem module, bat/tat, bam vao module de mo cai dat (cong tac, thanh truot, bang mau).
- Tab "Cau hinh": xem/chuyen/tao profile, luu cau hinh.
- Luu y: chu co dau hien bang font du phong cua Minecraft nen hoi nhoe, day la binh thuong.

## Neu menu khong hien
1. Vao the gioi, neu thay dong chat "[Spicy Client] da tai..." thi mod DA chay.
2. Mo menu bang lenh `/spicy` (khong can phim). Neu OK, vao Options > Controls > "Spicy Client" kiem tra phim "Mo menu" co bi gan trung/doi khong.
3. Neu khong thay dong chat: mod chua duoc tai. Mo `.minecraft/logs/latest.log`, tim "Spicy" hoac "spicyclient" va gui cho nguoi ho tro.

## Giai doan 2: cac module (19)
Combat: CPS, Armor HUD, Totem Counter, Target HUD, Reach Display
Movement: Sprint, Toggle Sneak, Auto Jump, Speed Display, Direction HUD
Render: Fullbright, Coordinates
Utility: Inventory HUD, Armor Durability, Potion HUD, Keystrokes, Ping, FPS, Timer
Chua co (se lam sau khi xac minh API): Hitbox, Entity ESP, Block Overlay, Chest Display, Waypoint, Screenshot, Raid Base Analysis.

## Phan tich can cu (chi ban do cua ban)
Base Scanner, Block Counter, Chest Counter, Container Statistics.
Chi quet trong the gioi 1 nguoi choi (singleplayer), ban kinh 4-24 khoi quanh ban. Khong hoat dong tren server nguoi khac.
Chua co: Schematic Viewer, hien thi thong tin cong trinh chi tiet.

## Giai doan 4: ve len man hinh va cong cu phan tich
Render: Entity ESP, Block Overlay, Chest Display, Waypoint (lenh /spicy wp add|del|list <ten>)
Combat: Hitbox Display
Utility: Screenshot (bat = chup 1 anh roi tu tat)
Raid: Nearest Container, Schematic Viewer (bo .schem/.litematic vao .minecraft/spicyclient/schematics)
Luu y: day la overlay 2D chieu tu toa do the gioi, chi dung o goc nhin thu nhat; lech nhe khi FOV dang bi hieu ung (chay nhanh).
ESP/Hitbox/Chest Display/quet can cu chi hoat dong trong the gioi 1 nguoi choi.
